import os
import subprocess
import json
from PyQt5.QtWidgets import QMessageBox, QDialog, QVBoxLayout, QListWidget, QPushButton, QLabel

class NBFCManager:
    """Class to manage NBFC (Notebook Fan Control) setup and configuration"""
    
    @staticmethod
    def is_nbfc_installed():
        """Check if NBFC is installed"""
        try:
            subprocess.run(['nbfc', '--version'], 
                          capture_output=True, 
                          text=True)
            return True
        except FileNotFoundError:
            return False
    
    @staticmethod
    def is_nbfc_running():
        """Check if NBFC service is running"""
        try:
            result = subprocess.run(['nbfc', 'status'], 
                                   capture_output=True, 
                                   text=True)
            return "ERROR: connect()" not in result.stderr
        except Exception:
            return False
    
    @staticmethod
    def is_nbfc_configured():
        """Check if NBFC is configured by looking for config file"""
        try:
            # First check if the service can start
            result = subprocess.run(['sudo', 'nbfc', 'start'], 
                                   capture_output=True, 
                                   text=True)
            # If there's an error about missing config file, it's not configured
            return "ERROR: /etc/nbfc/nbfc.json: No such file or directory" not in result.stderr
        except Exception:
            # If we can't run the command, assume it's not configured
            return False
    
    @staticmethod
    def update_nbfc_configs(parent=None):
        """Download available NBFC configs"""
        try:
            result = subprocess.run(['pkexec', 'nbfc', 'update'], 
                                    capture_output=True, 
                                    text=True)
            if parent:
                QMessageBox.information(parent, "NBFC Update", 
                                       "NBFC configuration database has been updated.")
            return True
        except Exception as e:
            if parent:
                QMessageBox.warning(parent, "NBFC Update Failed", 
                                   f"Failed to update NBFC configurations: {str(e)}")
            return False
    
    @staticmethod
    def get_recommended_config():
        """Get the recommended config for this system"""
        try:
            result = subprocess.run(['nbfc', 'config', '-r'], 
                                   capture_output=True, 
                                   text=True)
            
            # Check if a recommended config was found
            if "Found supported config:" in result.stdout:
                # Extract the config name
                lines = result.stdout.strip().split('\n')
                for i, line in enumerate(lines):
                    if "Found supported config:" in line and i+1 < len(lines):
                        return lines[i+1].strip()
            return None
        except Exception:
            return None
    
    @staticmethod
    def get_available_configs():
        """Get list of all available NBFC configs"""
        configs = []
        config_dirs = ['/usr/share/nbfc/configs', '/etc/nbfc/configs']
        
        for directory in config_dirs:
            if os.path.exists(directory):
                for file in os.listdir(directory):
                    if file.endswith('.json'):
                        configs.append(file[:-5])  # Remove .json extension
        
        return sorted(configs)
    
    @staticmethod
    def set_nbfc_config(config_name, parent=None):
        """Set NBFC to use the specified config"""
        try:
            result = subprocess.run(['pkexec', 'nbfc', 'config', '-s', config_name], 
                                   capture_output=True, 
                                   text=True)
            if "ERROR" in result.stderr:
                if parent:
                    QMessageBox.warning(parent, "Config Error", 
                                       f"Failed to set config: {result.stderr}")
                return False
            return True
        except Exception as e:
            if parent:
                QMessageBox.warning(parent, "Config Error", 
                                   f"Failed to set config: {str(e)}")
            return False
    
    @staticmethod
    def start_nbfc_service(parent=None):
        """Start the NBFC service"""
        try:
            result = subprocess.run(['pkexec', 'nbfc', 'start'], 
                                   capture_output=True, 
                                   text=True)
            if "ERROR" in result.stderr and "No such file or directory" not in result.stderr:
                if parent:
                    QMessageBox.warning(parent, "Service Error", 
                                      f"Failed to start NBFC service: {result.stderr}")
                return False
            return True
        except Exception as e:
            if parent:
                QMessageBox.warning(parent, "Service Error", 
                                   f"Failed to start NBFC service: {str(e)}")
            return False

    @staticmethod
    def setup_nbfc(parent=None):
        """Complete NBFC setup process with user interaction if needed"""
        if not NBFCManager.is_nbfc_installed():
            QMessageBox.critical(parent, "NBFC Not Installed", 
                               "Notebook Fan Control (NBFC) is not installed on this system.\n"
                               "Please install it using your package manager.")
            return False
        
        # If NBFC is already running, we're good
        if NBFCManager.is_nbfc_running():
            return True
        
        # Try to start the service first
        NBFCManager.start_nbfc_service(parent)
        
        # If service starts successfully, we're done
        if NBFCManager.is_nbfc_running():
            return True
        
        # If still not running, we need to update and configure
        msg = QMessageBox(parent)
        msg.setIcon(QMessageBox.Information)
        msg.setWindowTitle("NBFC Setup Required")
        msg.setText("Notebook Fan Control needs to be configured.")
        msg.setInformativeText("This is required for fan control features. "
                              "Would you like to set it up now?")
        msg.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        
        if msg.exec_() != QMessageBox.Yes:
            return False
        
        # Update configs
        NBFCManager.update_nbfc_configs(parent)
        
        # Try to get recommended config
        recommended = NBFCManager.get_recommended_config()
        
        if recommended:
            msg = QMessageBox(parent)
            msg.setIcon(QMessageBox.Question)
            msg.setWindowTitle("NBFC Configuration")
            msg.setText(f"Recommended configuration found: {recommended}")
            msg.setInformativeText("Would you like to use this configuration?")
            msg.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
            
            if msg.exec_() == QMessageBox.Yes:
                if NBFCManager.set_nbfc_config(recommended, parent):
                    NBFCManager.start_nbfc_service(parent)
                    return NBFCManager.is_nbfc_running()
        
        # If we don't have a recommended config or user declined it,
        # show dialog for manual selection
        config_dialog = ConfigSelectionDialog(parent)
        if config_dialog.exec_() == QDialog.Accepted and config_dialog.selected_config:
            if NBFCManager.set_nbfc_config(config_dialog.selected_config, parent):
                NBFCManager.start_nbfc_service(parent)
                return NBFCManager.is_nbfc_running()
        
        return False


class ConfigSelectionDialog(QDialog):
    """Dialog for selecting an NBFC configuration"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Select NBFC Configuration")
        self.setMinimumWidth(400)
        self.setMinimumHeight(300)
        
        self.selected_config = None
        
        layout = QVBoxLayout(self)
        
        # Instructions
        label = QLabel("Please select a configuration for your device:")
        layout.addWidget(label)
        
        # Config list
        self.config_list = QListWidget()
        layout.addWidget(self.config_list)
        
        # Populate list
        configs = NBFCManager.get_available_configs()
        for config in configs:
            self.config_list.addItem(config)
        
        # Buttons
        button_layout = QVBoxLayout()
        select_button = QPushButton("Select")
        select_button.clicked.connect(self.accept_selection)
        cancel_button = QPushButton("Cancel")
        cancel_button.clicked.connect(self.reject)
        
        button_layout.addWidget(select_button)
        button_layout.addWidget(cancel_button)
        layout.addLayout(button_layout)
    
    def accept_selection(self):
        """Accept the selected configuration"""
        current_item = self.config_list.currentItem()
        if current_item:
            self.selected_config = current_item.text()
            self.accept()
        else:
            QMessageBox.warning(self, "Selection Required", 
                              "Please select a configuration from the list.")