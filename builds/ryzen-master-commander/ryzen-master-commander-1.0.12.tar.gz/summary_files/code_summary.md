Project Root: /home/sam/github/Ryzen-Master-Commander
Project Structure:
```
.
|-- .gitignore
|-- LICENSE
|-- README.md
|-- bin
    |-- ryzen-master-commander
    |-- ryzen-master-commander-helper
|-- build_all.sh
|-- build_arch.sh
|-- build_deb.sh
|-- build_rpm.sh
|-- builds
    |-- ryzen-master-commander
        |-- PKGBUILD
        |-- ryzen-master-commander-1.0.10-1-any.pkg.tar.zst
        |-- ryzen-master-commander-1.0.10-1.noarch.rpm
        |-- ryzen-master-commander-1.0.10.tar.gz
        |-- ryzen-master-commander-1.0.11-1-any.pkg.tar.zst
        |-- ryzen-master-commander-1.0.11.tar.gz
        |-- ryzen-master-commander-1.0.5.tar.gz
        |-- ryzen-master-commander-1.0.6-1-any.pkg.tar.zst
        |-- ryzen-master-commander-1.0.6.tar.gz
        |-- ryzen-master-commander-1.0.7-1-any.pkg.tar.zst
        |-- ryzen-master-commander-1.0.7.tar.gz
        |-- ryzen-master-commander-1.0.8.tar.gz
        |-- ryzen-master-commander-1.0.9.tar.gz
        |-- ryzen-master-commander_1.0.10.deb
        |-- ryzen-master-commander_1.0.7.deb
        |-- ryzen-master-commander_1.0.8.deb
        |-- ryzen-master-commander_1.0.9.deb
|-- img
    |-- fan_curve.png
    |-- icon.png
    |-- main_ui.png
    |-- profile_saver.png
    |-- ui_w_graph.png
|-- install_fan_profile.sh
|-- manifest.in
|-- polkit
    |-- com.merrythieves.ryzenadj.policy
|-- requirements.txt
|-- ryzen_master_commander
    |-- __init__.py
    |-- app
        |-- __init__.py
        |-- fan_profile_editor.py
        |-- graphs.py
        |-- main_window.py
        |-- nbfc_manager.py
        |-- profile_manager.py
        |-- system_utils.py
    |-- main.py
|-- setup.py
|-- share
    |-- applications
        |-- ryzen-master-commander.desktop
    |-- icons
        |-- hicolor
            |-- 128x128
                |-- apps
                    |-- ryzen-master-commander.png
            |-- 16x16
                |-- apps
                    |-- ryzen-master-commander.png
            |-- 32x32
                |-- apps
                    |-- ryzen-master-commander.png
            |-- 64x64
                |-- apps
                    |-- ryzen-master-commander.png
    |-- ryzen-master-commander
        |-- fan_profiles
            |-- GPD_Win_Mini2.json
        |-- tdp_profiles
            |-- WinMini-Balanced.json
            |-- WinMini-BatterySaver.json
            |-- WinMini-MaxPerformance.json
|-- tdp_profiles
|-- version.txt

```

---
## File: manifest.in

```in
include LICENSE README.md requirements.txt
recursive-include ryzen_master_commander *.py
recursive-include share *
recursive-include bin *
recursive-include polkit *
recursive-include img *

```
---
## File: requirements.txt

```txt
numpy
Pillow
pystray
```
---
## File: ryzen_master_commander/app/fan_profile_editor.py

```py
import os
import glob
import json
import subprocess
from PyQt6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGroupBox,
                            QLabel, QComboBox, QPushButton, QLineEdit, QMessageBox)
from PyQt6.QtCore import Qt, QPointF, QEvent
# from PyQt6.QtGui import QCursor

import pyqtgraph as pg

class FanProfileEditor(QMainWindow):
    def __init__(self, current_nbfc_profile_name=None):
        super().__init__()
        self.current_nbfc_profile_name_from_main = current_nbfc_profile_name
        
        self.points = [(20, 0), (40, 30), (60, 60), (80, 100)]
        self.current_config = None
        
        self.hover_point_index = None
        self.drag_point_index = None
        self.is_dragging = False  # Explicit tracking of drag state
        
        self.nbfc_configs_dir = "/usr/share/nbfc/configs/"
        self.view_box = None
        
        self.init_ui()
    
    def init_ui(self):
        self.setWindowTitle("Fan Curve Editor")
        self.resize(800, 650)
        
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        
        # Title
        title_label = QLabel("Fan Curve Editor")
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        font = title_label.font(); font.setPointSize(16); font.setBold(True)
        title_label.setFont(font)
        main_layout.addWidget(title_label)
        
        # Profile Selection Group
        profiles_group = QGroupBox("Available Profiles")
        profiles_layout = QHBoxLayout(profiles_group)
        profiles_layout.addWidget(QLabel("Select Profile:"))
        self.profiles_list = self.get_available_profiles()
        self.profile_dropdown = QComboBox()
        self.profile_dropdown.addItems(self.profiles_list)
        self.profile_dropdown.currentIndexChanged.connect(self.on_profile_selected)
        profiles_layout.addWidget(self.profile_dropdown, 1)
        load_btn = QPushButton("Load"); load_btn.clicked.connect(self.load_selected_profile)
        profiles_layout.addWidget(load_btn)
        apply_btn = QPushButton("Apply"); apply_btn.clicked.connect(self.apply_selected_profile)
        profiles_layout.addWidget(apply_btn)
        main_layout.addWidget(profiles_group)
        
        # Plot Widget Setup - Using direct PyQtGraph widget
        self.plot_widget = pg.PlotWidget()
        main_layout.addWidget(self.plot_widget)

        self.view_box = self.plot_widget.plotItem.vb
        self.view_box.setMouseMode(pg.ViewBox.PanMode)
        self.view_box.setMouseEnabled(x=False, y=False)  # Disable panning
        self.plot_widget.plotItem.setMenuEnabled(False)  # Disable context menu

        self.plot_widget.setLabel('left', 'Fan Speed (%)')
        self.plot_widget.setLabel('bottom', 'Temperature (°C)')
        self.plot_widget.setXRange(0, 100, padding=0.01)
        self.plot_widget.setYRange(0, 100, padding=0.01)
        self.plot_widget.showGrid(x=True, y=True)
        self.plot_widget.setTitle('Fan Speed Curve')
        
        # Important: Enable mouse tracking for hover effects
        self.plot_widget.setMouseTracking(True)

        # Plot Items
        self.curve_item = self.plot_widget.plot([], [], pen='b', symbol='o', symbolSize=8, symbolBrush='b')
        self.selected_point_item = pg.ScatterPlotItem([], [], size=12, pen=pg.mkPen('r', width=2), brush=pg.mkBrush(255,0,0,120))
        self.plot_widget.addItem(self.selected_point_item)
        self.coord_text_item = pg.TextItem(anchor=(0.5,1.8))
        self.plot_widget.addItem(self.coord_text_item)
        self.coord_text_item.hide()

        # Install event filter for direct mouse event handling
        self.plot_widget.viewport().installEventFilter(self)
        
        # Curve Controls Group
        controls_group = QGroupBox("Curve Controls")
        controls_layout = QVBoxLayout(controls_group)
        
        # Instructions
        instructions_layout = QVBoxLayout()
        drag_instruction = QLabel("<i>Drag to move. Double click to add. Right click to remove.</i>")
        drag_instruction.setAlignment(Qt.AlignmentFlag.AlignCenter)
        instructions_layout.addWidget(drag_instruction)
        
        # Reset button
        reset_layout = QHBoxLayout()
        reset_btn = QPushButton("Reset")
        reset_btn.clicked.connect(self.reset_curve)
        reset_layout.addStretch()
        reset_layout.addWidget(reset_btn)
        reset_layout.addStretch()
        
        controls_layout.addLayout(instructions_layout)
        controls_layout.addLayout(reset_layout)
        main_layout.addWidget(controls_group)
        
        # Save Profile Group
        save_group = QGroupBox("Save Profile")
        save_layout = QHBoxLayout(save_group); save_layout.addWidget(QLabel("Profile Name:"))
        self.custom_profile_name = QLineEdit("MyCustomProfile")
        save_layout.addWidget(self.custom_profile_name, 1)
        save_btn = QPushButton("Save Custom Profile"); save_btn.clicked.connect(self.save_custom_profile)
        save_layout.addWidget(save_btn)
        main_layout.addWidget(save_group)
        
        self.update_plot()
        self.select_initial_profile()
    
    def eventFilter(self, obj, event):
        """Direct event filter for mouse events on the plot widget viewport."""
        if obj is self.plot_widget.viewport():
            event_type = event.type()
            
            # Mouse press - start drag operation
            if event_type == QEvent.Type.MouseButtonPress and event.button() == Qt.MouseButton.LeftButton:
                scene_pos = self.plot_widget.mapToScene(event.pos())
                idx = self._get_point_at_scene_pos(scene_pos)
                if idx is not None:
                    self.drag_point_index = idx
                    self.is_dragging = True
                    self._update_hover_point(scene_pos)
                    return True  # Event handled
                # Check for double click to add point
                elif event.type() == QEvent.Type.MouseButtonDblClick:  # Changed from doubleClick() method
                    data_pos = self.view_box.mapSceneToView(scene_pos)
                    self._add_point_at(data_pos.x(), data_pos.y())
                    return True
            
            # Mouse move - update point position during drag
            elif event_type == QEvent.Type.MouseMove:
                scene_pos = self.plot_widget.mapToScene(event.pos())
                if self.is_dragging and self.drag_point_index is not None:
                    data_pos = self.view_box.mapSceneToView(scene_pos)
                    self._update_point_position(self.drag_point_index, data_pos.x(), data_pos.y())
                    return True
                else:
                    self._update_hover_point(scene_pos)
            
            # Mouse release - end drag operation
            elif event_type == QEvent.Type.MouseButtonRelease and event.button() == Qt.MouseButton.LeftButton:
                if self.is_dragging:
                    scene_pos = self.plot_widget.mapToScene(event.pos())
                    data_pos = self.view_box.mapSceneToView(scene_pos)
                    
                    # Finalize position if still dragging
                    if self.drag_point_index is not None:
                        self._update_point_position(self.drag_point_index, data_pos.x(), data_pos.y())
                    
                    # Reset drag state
                    self.is_dragging = False
                    self.drag_point_index = None
                    
                    # Update hover for current position
                    self._update_hover_point(scene_pos)
                    return True
            
            # Right-click to remove a point
            elif event_type == QEvent.Type.MouseButtonPress and event.button() == Qt.MouseButton.RightButton:
                scene_pos = self.plot_widget.mapToScene(event.pos())
                idx = self._get_point_at_scene_pos(scene_pos)
                if idx is not None:
                    self._remove_point_at_index(idx)
                    return True
        
        # For all other objects and events, pass to base implementation
        return super().eventFilter(obj, event)
    
    def _add_point_at(self, x, y):
        """Add a new point at the given coordinates."""
        new_temp = round(max(0, min(100, x)))
        new_speed = round(max(0, min(100, y)))
        if (new_temp, new_speed) not in self.points:
            self.points.append((new_temp, new_speed))
            self.update_plot()
    
    def _update_point_position(self, idx, x, y):
        """Update the position of a point at the given index."""
        if 0 <= idx < len(self.points):
            new_temp = round(max(0, min(100, x)))
            new_speed = round(max(0, min(100, y)))
            self.points[idx] = (new_temp, new_speed)
            
            # Update coordinate label
            self.coord_text_item.setText(f"({new_temp}, {new_speed})")
            self.coord_text_item.setPos(new_temp, new_speed)
            self.coord_text_item.show()
            
            self.update_plot()
    
    def _remove_point_at_index(self, idx):
        """Remove the point at the given index if possible."""
        if 0 <= idx < len(self.points):
            if len(self.points) > 2:
                self.points.pop(idx)
                
                # Update hover and drag indices
                if self.hover_point_index == idx:
                    self.hover_point_index = None
                if self.drag_point_index == idx:
                    self.drag_point_index = None
                    self.is_dragging = False
                
                self.coord_text_item.hide()
                self.update_plot()
            else:
                QMessageBox.information(self, "Can't Remove", "Fan curve must have at least 2 points.")
    
    def _update_hover_point(self, scene_pos):
        """Update the hover point based on cursor position."""
        idx = self._get_point_at_scene_pos(scene_pos)
        old_hover_idx = self.hover_point_index
        self.hover_point_index = idx
        
        if idx is not None and 0 <= idx < len(self.points):
            pt_x, pt_y = self.points[idx]
            self.coord_text_item.setText(f"({pt_x}, {pt_y})")
            self.coord_text_item.setPos(pt_x, pt_y)
            self.coord_text_item.show()
            # Change cursor to hand cursor to indicate draggable point
            self.plot_widget.setCursor(Qt.CursorShape.OpenHandCursor)
        else:
            self.coord_text_item.hide()
            # Reset cursor to default
            self.plot_widget.setCursor(Qt.CursorShape.ArrowCursor)
        
        if old_hover_idx != self.hover_point_index:
            self.update_plot()
    
    def _get_point_at_scene_pos(self, scene_pos, sensitivity_pixels=12):
        """Find the index of the point near the given scene position."""
        if not self.view_box:
            return None
        
        mouse_data_pos = self.view_box.mapSceneToView(scene_pos)
        
        # Convert sensitivity from pixels to data units
        offset_scene_pos = QPointF(scene_pos.x() + sensitivity_pixels, scene_pos.y())
        offset_data_pos = self.view_box.mapSceneToView(offset_scene_pos)
        data_sensitivity = abs(offset_data_pos.x() - mouse_data_pos.x())
        
        mx, my = mouse_data_pos.x(), mouse_data_pos.y()
        
        # Find the closest point within sensitivity range
        closest_idx = None
        closest_dist = float('inf')
        
        for i, (px, py) in enumerate(self.points):
            # Calculate distance between mouse position and point
            dist = ((mx - px) ** 2 + (my - py) ** 2) ** 0.5
            if dist < data_sensitivity and dist < closest_dist:
                closest_dist = dist
                closest_idx = i
        
        return closest_idx
    
    def select_initial_profile(self):
        """Selects the initial profile in the dropdown, if applicable."""
        initial_profile_to_set = None
        if self.current_nbfc_profile_name_from_main and \
           self.current_nbfc_profile_name_from_main not in ["n/a", "--"]:
            if self.current_nbfc_profile_name_from_main in self.profiles_list:
                initial_profile_to_set = self.current_nbfc_profile_name_from_main
        
        if initial_profile_to_set:
            try: 
                idx = self.profiles_list.index(initial_profile_to_set)
                self.profile_dropdown.setCurrentIndex(idx)
            except ValueError:
                if self.profiles_list: self.profile_dropdown.setCurrentIndex(0)
        elif self.profiles_list:
            self.profile_dropdown.setCurrentIndex(0)
        
        if self.profile_dropdown.currentIndex() == 0 and self.profiles_list and not self.current_config:
             self.load_selected_profile()

    def get_available_profiles(self):
        """Scans the NBFC configs directory for .json files and returns their names."""
        try:
            system_profiles = glob.glob(os.path.join(self.nbfc_configs_dir, "*.json"))
            profile_names = [os.path.splitext(os.path.basename(p))[0] for p in system_profiles]
            return sorted(profile_names)
        except Exception as e:
            print(f"Error getting available profiles: {e}")
            return []
    
    def on_profile_selected(self, index):
        """Handles selection change in the profile dropdown."""
        if index >= 0:
            self.load_selected_profile()
    
    def load_selected_profile(self):
        """Loads fan curve data from the selected NBFC profile file."""
        profile_name = self.profile_dropdown.currentText()
        if not profile_name: return
        
        self.custom_profile_name.setText(profile_name)
        file_path = os.path.join(self.nbfc_configs_dir, f"{profile_name}.json")
        
        if not os.path.exists(file_path):
            QMessageBox.critical(self, "Error", f"Profile '{profile_name}' not found at {file_path}.")
            self.reset_curve(update_dropdown=False); self.update_plot()
            return
            
        try:
            with open(file_path, 'r') as f: config = json.load(f)
            self.current_config = config
            
            curve_points = []
            if 'FanConfigurations' in config and config['FanConfigurations']:
                fan_config = config['FanConfigurations'][0] 
                if 'TemperatureThresholds' in fan_config and fan_config['TemperatureThresholds']:
                    for threshold in fan_config['TemperatureThresholds']:
                        if 'UpThreshold' in threshold and 'FanSpeed' in threshold:
                            curve_points.append((threshold['UpThreshold'], threshold['FanSpeed']))
                elif 'FanSpeedPercentageOverrides' in fan_config and fan_config['FanSpeedPercentageOverrides']:
                    overrides = fan_config['FanSpeedPercentageOverrides']
                    if overrides and isinstance(overrides, list) and len(overrides) > 0:
                        if isinstance(overrides[0], dict) and 'Temperature' in overrides[0] and 'FanSpeed' in overrides[0]:
                            for override in overrides: curve_points.append((override['Temperature'], override['FanSpeed']))
                        elif isinstance(overrides[0], dict) and 'FanSpeedPercentage' in overrides[0] and 'FanSpeedValue' in overrides[0]:
                            min_temp, max_temp = 30, 90; step = (max_temp - min_temp) / (len(overrides) -1) if len(overrides)>1 else 10
                            for i, override in enumerate(overrides): curve_points.append((min_temp + i * step, override['FanSpeedPercentage']))
                
                if curve_points: self.points = [(round(p[0]), round(p[1])) for p in curve_points]
                else: QMessageBox.information(self, "Note", f"No fan curve data in '{profile_name}'. Using default."); self.reset_curve(update_dropdown=False)
            else: QMessageBox.warning(self, "Warning", f"Profile '{profile_name}' no fan config. Using default."); self.reset_curve(update_dropdown=False)
            self.update_plot()
                
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load profile '{profile_name}': {str(e)}")
            self.reset_curve(update_dropdown=False); self.update_plot()
    
    def apply_selected_profile(self):
        """Applies the currently selected profile using 'nbfc' command with pkexec."""
        profile_name = self.profile_dropdown.currentText()
        if not profile_name: QMessageBox.warning(self, "Warning", "Please select a profile."); return
        try:
            subprocess.run(['pkexec', 'nbfc', 'config', '-a', profile_name], check=True, capture_output=True, text=True)
            QMessageBox.information(self, "Success", f"Applied fan profile '{profile_name}'.")
        except subprocess.CalledProcessError as e:
            error_details = f"Error: {e.stderr or e.stdout or str(e)}"
            QMessageBox.critical(self, "Error", f"Failed to apply profile '{profile_name}'.\n{error_details}")
        except FileNotFoundError:
            QMessageBox.critical(self, "Error", "pkexec or nbfc command not found.")
    
    def save_custom_profile(self):
        """Saves the current fan curve as a new NBFC profile .json file."""
        name = self.custom_profile_name.text().strip()
        if not name: QMessageBox.warning(self, "Warning", "Please enter a profile name."); return
        if any(c in name for c in "/\\:*?\"<>|"): QMessageBox.warning(self, "Warning", "Profile name contains invalid characters."); return

        if self.current_config: config = self.current_config.copy(); config["NotebookModel"] = name
        else: config = { "NotebookModel": name, "Author": "Ryzen Master Commander", "EcPollInterval": 5000, "ReadWriteWords": False, "CriticalTemperature": 85, "FanConfigurations": [{"ReadRegister": 122, "WriteRegister": 122, "MinSpeedValue": 0, "MaxSpeedValue": 255, "ResetRequired": True, "FanSpeedResetValue": 0, "FanDisplayName": "Fan"}]}
        if "FanConfigurations" not in config or not config["FanConfigurations"]: config["FanConfigurations"] = [{"ReadRegister": 122, "WriteRegister": 122}] 
        if not isinstance(config["FanConfigurations"], list): config["FanConfigurations"] = [config["FanConfigurations"]]
        if not config["FanConfigurations"]: config["FanConfigurations"].append({})
        
        thresholds = []
        if self.points:
            t_0, s_0 = self.points[0]; thresholds.append({"UpThreshold": int(t_0), "DownThreshold": int(max(0, t_0 - 5)), "FanSpeed": float(s_0)})
            for i in range(1, len(self.points)):
                t_curr, s_curr = self.points[i]; t_prev, _ = self.points[i-1]
                down_thresh = min(int(t_prev + 1), int(t_curr)); down_thresh = max(0, down_thresh)
                thresholds.append({"UpThreshold": int(t_curr), "DownThreshold": down_thresh, "FanSpeed": float(s_curr)})
        config["FanConfigurations"][0]["TemperatureThresholds"] = thresholds
        config["FanConfigurations"][0].pop("FanSpeedPercentageOverrides", None)

        try:
            temp_dir = os.path.expanduser("~/.config/ryzen-master-commander/temp_profiles")
            os.makedirs(temp_dir, exist_ok=True)
            temp_file = os.path.join(temp_dir, f"{name}.json")
            with open(temp_file, 'w') as f: json.dump(config, f, indent=2)
            target_file = os.path.join(self.nbfc_configs_dir, f"{name}.json")
            subprocess.run(['pkexec', 'cp', temp_file, target_file], check=True, capture_output=True, text=True)
            QMessageBox.information(self, "Success", f"Saved profile to {target_file}")
            self.refresh_ui_after_save(name)
        except subprocess.CalledProcessError as e:
            error_details = f"Error: {e.stderr or e.stdout or str(e)}"
            QMessageBox.critical(self, "Error", f"Failed to save profile with pkexec.\n{error_details}")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save profile: {str(e)}")

    def refresh_ui_after_save(self, saved_profile_name):
        """Refreshes the profile list and selects the newly saved profile."""
        self.profiles_list = self.get_available_profiles()
        self.profile_dropdown.clear()
        self.profile_dropdown.addItems(self.profiles_list)
        if saved_profile_name in self.profiles_list:
            self.profile_dropdown.setCurrentText(saved_profile_name)
        elif self.profiles_list: self.profile_dropdown.setCurrentIndex(0)
    
    def update_plot(self):
        """Updates the fan curve plot with current points and highlights."""
        self.points = sorted([(round(p[0]), round(p[1])) for p in self.points], key=lambda p: p[0])
        temps, speeds = zip(*self.points) if self.points else ([], [])
        self.curve_item.setData(temps, speeds)
        
        self.selected_point_item.clear()
        highlight_idx = self.drag_point_index if self.drag_point_index is not None else self.hover_point_index
        if highlight_idx is not None and 0 <= highlight_idx < len(self.points):
            px, py = self.points[highlight_idx]
            self.selected_point_item.addPoints([px], [py])
    
    def reset_curve(self, update_dropdown=True):
        """Resets the fan curve to a default state."""
        self.points = [(20,0), (40,30), (60,60), (80,100)]
        if update_dropdown: self.current_config = None; self.custom_profile_name.setText("MyCustomProfile")
        self.hover_point_index = None; self.drag_point_index = None
        self.is_dragging = False
        self.coord_text_item.hide()
        self.update_plot()
```
---
## File: ryzen_master_commander/app/graphs.py

```py
from PyQt6.QtWidgets import QWidget, QVBoxLayout
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont, QColor, QPen
import pyqtgraph as pg
# import numpy as np

class CombinedGraph(QWidget):
    def __init__(self, parent=None):
        super(CombinedGraph, self).__init__(parent)
        self.temperature_readings = []
        self.fanspeed_readings = []
        self.time_points = []
        
        # Configure global PyQtGraph settings
        pg.setConfigOptions(antialias=True)
        
        # Create layout
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        # Create PlotWidget - use transparent background to respect app theme
        self.plot_widget = pg.PlotWidget(background=None)
        layout.addWidget(self.plot_widget)
        
        # Setup the plot
        self.setup_plot()
        
    def setup_plot(self):
        # Enable grid
        self.plot_widget.showGrid(x=True, y=True, alpha=0.3)
        
        # Define colors for temperature and fan speed
        temp_color = '#3498db'  # Blue
        fan_color = '#e74c3c'   # Red
        
        # Setup left Y axis (Temperature)
        left_axis = self.plot_widget.getAxis('left')
        left_axis.setLabel(text='Temperature', units='°C', color=temp_color)
        left_axis.setPen(pg.mkPen(color=temp_color, width=2))
        left_axis.setTextPen(temp_color)
        
        # Setup right Y axis (Fan Speed)
        self.plot_widget.showAxis('right') # Explicitly tell PlotItem to show the right axis
        right_axis = self.plot_widget.getAxis('right')
        right_axis.setLabel(text='Fan Speed', units='%', color=fan_color) # Set label
        right_axis.setPen(pg.mkPen(color=fan_color, width=2))
        right_axis.setTextPen(fan_color)
        right_axis.setStyle(showValues=True) # Ensure tick values are shown
        # Add tick values for fan speed (0%, 25%, 50%, 75%, 100%)
        right_axis.setTicks([[(0, '0%'), (25, '25%'), (50, '50%'), (75, '75%'), (100, '100%')]])
        
        # Setup bottom X axis (Time)
        bottom_axis = self.plot_widget.getAxis('bottom')
        bottom_axis.setLabel('Time (seconds)')
        
        # Create ViewBox for Fan Speed
        self.fan_view = pg.ViewBox()
        self.plot_widget.scene().addItem(self.fan_view) # Add to scene
        right_axis.linkToView(self.fan_view) # Link the axis to this view
        self.fan_view.setXLink(self.plot_widget.getViewBox()) # Link X axes
        # Fix fan speed range to 0-100%
        self.fan_view.setYRange(0, 100, padding=0)
        
        # Create temperature plot
        self.temp_curve = pg.PlotCurveItem(
            pen=pg.mkPen(color=temp_color, width=3),
            symbolBrush=temp_color,
            symbolPen='w',
            symbol='o',
            symbolSize=7,
            name="Temperature"
        )
        self.plot_widget.addItem(self.temp_curve)
        
        # Create fan speed plot (on secondary y-axis)
        self.fan_curve = pg.PlotCurveItem(
            pen=pg.mkPen(color=fan_color, width=3),
            symbolBrush=fan_color,
            symbolPen='w',
            symbol='s',
            symbolSize=7,
            name="Fan Speed"
        )
        self.fan_view.addItem(self.fan_curve) # Add to the fan_view
        
        # Create legend and position it below the graph
        self.legend = pg.LegendItem() # Create instance without initial offset
        self.legend.setParentItem(self.plot_widget.graphicsItem()) # Parent is PlotItem
        # Anchor top-center of legend to bottom-center of plot item, with a 10px downward offset
        self.legend.anchor(itemPos=(0.5, 0), parentPos=(0.5, 1), offset=(0, 10)) 
        
        # Add items to legend
        self.legend.addItem(self.temp_curve, "Temperature (°C)")
        # Create a proxy item for fan speed for the legend
        self.fan_proxy = pg.PlotDataItem( # Use PlotDataItem for legend proxy if curve itself is complex
            pen=pg.mkPen(color=fan_color, width=3),
            symbolBrush=fan_color,
            symbolPen='w',
            symbol='s',
            symbolSize=7
        )
        self.legend.addItem(self.fan_proxy, "Fan Speed (%)")
        
        # Connect resize event to update views and ensure sync
        self.plot_widget.getViewBox().sigResized.connect(self.updateViews)
        
        # Update views initially
        self.updateViews()
        
    def updateViews(self):
        # Keep the views in sync when resizing
        # The main ViewBox (getViewBox()) controls the geometry of the plot area
        # The fan_view needs to match this geometry
        main_vb_rect = self.plot_widget.getViewBox().sceneBoundingRect()
        self.fan_view.setGeometry(main_vb_rect)
        
        # This call is important to sync the X-axis state (range, etc.)
        # from the main ViewBox to the fan_view's X-axis.
        self.fan_view.linkedViewChanged(self.plot_widget.getViewBox(), self.fan_view.XAxis)
        
    def update_data(self, temperature, fan_speed):
        if temperature == "n/a" and fan_speed == "n/a":
            return
        
        # Add current time (seconds since start)
        if not self.time_points:
            self.time_points.append(0)
        else:
            self.time_points.append(self.time_points[-1] + 1)
        
        # Keep only the last 60 points
        if len(self.time_points) > 60:
            self.time_points = self.time_points[-60:]
        
        # Update temperature data
        if temperature != "n/a":
            self.temperature_readings.append(float(temperature))
        else:
            # If no reading, use the previous value or zero
            self.temperature_readings.append(self.temperature_readings[-1] if self.temperature_readings else 0)
            
        # Keep only the last 60 points
        if len(self.temperature_readings) > 60:
            self.temperature_readings = self.temperature_readings[-60:]
        
        # Update fan speed data
        if fan_speed != "n/a":
            self.fanspeed_readings.append(float(fan_speed))
        else:
            # If no reading, use the previous value or zero
            self.fanspeed_readings.append(self.fanspeed_readings[-1] if self.fanspeed_readings else 0)
            
        # Keep only the last 60 points
        if len(self.fanspeed_readings) > 60:
            self.fanspeed_readings = self.fanspeed_readings[-60:]
        
        # Ensure all data arrays have the same length matching the shortest one
        min_len = min(len(self.time_points), len(self.temperature_readings), len(self.fanspeed_readings))
        if min_len == 0: # Avoid issues if no data yet
            time_data, temp_data, fan_data = [], [], []
        else:
            time_data = self.time_points[-min_len:]
            temp_data = self.temperature_readings[-min_len:]
            fan_data = self.fanspeed_readings[-min_len:]
        
        # Update plot data
        self.temp_curve.setData(time_data, temp_data)
        self.fan_curve.setData(time_data, fan_data)
        if self.fan_proxy: # Check if fan_proxy exists before setting data
             self.fan_proxy.setData(time_data, fan_data)  # Update the legend proxy
        
        # Auto-scale temperature y-axis
        if temp_data:
            max_temp = max(temp_data) + 5
            min_temp = max(0, min(temp_data) - 5)
            # Ensure max_temp is at least a reasonable value like 50, and min_temp is not negative
            self.plot_widget.setYRange(min_temp, max(max_temp, 50.0)) 
        else:
            self.plot_widget.setYRange(0, 50) # Default if no data

        # Make sure the fan scale stays 0-100
        self.fan_view.setYRange(0, 100, padding=0)
        
        # Update ViewBox to ensure correct sizing and linking
        self.updateViews()
```
---
## File: ryzen_master_commander/app/main_window.py

```py
import os
import subprocess
from PyQt6.QtWidgets import (QMainWindow, QWidget, QHBoxLayout, QVBoxLayout, QLabel, 
                            QSlider, QGroupBox, QPushButton, 
                            QRadioButton, QStatusBar, QFrame, QSplitter, QApplication,
                            QSystemTrayIcon, QMenu, QMessageBox)
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QIcon, QAction
# import sys

from ryzen_master_commander.app.graphs import CombinedGraph
from ryzen_master_commander.app.system_utils import get_system_readings
from ryzen_master_commander.app.profile_manager import ProfileManager
from ryzen_master_commander.app.fan_profile_editor import FanProfileEditor
from ryzen_master_commander.app.nbfc_manager import NBFCManager

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        
        # Initialize instance variables
        self.profile_manager = ProfileManager()
        self.fan_speed_adjustment_delay = None
        self.graph_visible = True

        NBFCManager.setup_nbfc(self)
        
        # Set up the UI
        self.init_ui()
        
        # Set up system tray
        self.setup_system_tray()
        
        # Set auto control by default
        self.radio_auto_control.setChecked(True)
        # self.set_auto_control()
        
        # Start reading system values
        self.refresh_timer = QTimer(self)
        self.refresh_timer.timeout.connect(self.update_readings)
        self.refresh_timer.start(5000)  # Initial refresh every 5 seconds
        
        # Schedule first reading
        QTimer.singleShot(1000, self.update_readings)

    def check_nbfc_running(self):
        """Check if NBFC service is running"""
        try:
            result = subprocess.run(['nbfc', 'status'], 
                                   capture_output=True, 
                                   text=True)
            return "ERROR: connect()" not in result.stderr
        except Exception:
            print(f"nbfc not running: {result.stderr}")
            return False
    
    def start_nbfc_service(self):
        """Prompt user to start NBFC service"""
        # msg = QMessageBox(self)
        # msg.setIcon(QMessageBox.Warning)
        # msg.setWindowTitle("NBFC Service Not Running")
        # msg.setText("The notebook fan control service (NBFC) is not running.")
        # msg.setInformativeText("Fan control features require NBFC to be running. Would you like to start it now?")
        # msg.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        # msg.setDefaultButton(QMessageBox.Yes)
        
        # if msg.exec_() == QMessageBox.Yes:

        print("Attempting to start NBFC service...")
        try:
            subprocess.run(['pkexec', 'nbfc', 'start'], check=True)
            # QMessageBox.information(self, "Success", "NBFC service started successfully.")
        except subprocess.CalledProcessError:
            QMessageBox.critical(self, "Error", "Failed to start NBFC service. Fan control features may not work properly.")
    
    def setup_system_tray(self):
        """Set up the system tray icon and menu"""
        # Create the tray icon
        self.tray_icon = QSystemTrayIcon(self)
        
        # Get the application icon
        app_icon = QApplication.windowIcon()
        if not app_icon.isNull():
            self.tray_icon.setIcon(app_icon)
        else:
            # Try to find icon in standard locations
            for path in ["/usr/share/icons/hicolor/128x128/apps/ryzen-master-commander.png",
                        "./share/icons/hicolor/128x128/apps/ryzen-master-commander.png",
                        "./img/icon.png"]:
                if os.path.exists(path):
                    self.tray_icon.setIcon(QIcon(path))
                    break
        
        # Create the tray menu
        tray_menu = QMenu()
        
        # Add actions to the tray menu
        show_action = QAction("Show", self)
        show_action.triggered.connect(self.show_from_tray)
        tray_menu.addAction(show_action)
        
        toggle_auto_action = QAction("Auto Fan Control", self)
        toggle_auto_action.setCheckable(True)
        toggle_auto_action.setChecked(self.radio_auto_control.isChecked())
        toggle_auto_action.triggered.connect(self.toggle_auto_control_from_tray)
        tray_menu.addAction(toggle_auto_action)
        self.toggle_auto_action = toggle_auto_action
        
        tray_menu.addSeparator()
        
        quit_action = QAction("Quit", self)
        quit_action.triggered.connect(self.quit_application)
        tray_menu.addAction(quit_action)
        
        # Set the context menu for the tray icon
        self.tray_icon.setContextMenu(tray_menu)
        
        # Connect signals
        self.tray_icon.activated.connect(self.tray_icon_activated)
        
        # Show the tray icon
        self.tray_icon.show()
        
        # Update tooltip with temperature and fan speed
        self.update_tray_tooltip()

    def update_tray_tooltip(self):
        """Update tray icon tooltip with current system information"""
        temp_text = self.temp_label.text().replace("Temperature: ", "")
        fan_text = self.fan_speed_label.text().replace("Fan Speed: ", "")
        profile_text = self.current_profile_label.text().replace("Current Profile: ", "")
        
        tooltip = f"Ryzen Master Commander\n{temp_text} | {fan_text}\nProfile: {profile_text}"
        self.tray_icon.setToolTip(tooltip)

    def tray_icon_activated(self, reason):
        """Handle tray icon activation"""
        if reason == QSystemTrayIcon.Trigger:  # Left click
            if self.isVisible():
                self.hide()
            else:
                self.show_from_tray()

    def show_from_tray(self):
        """Show the main window from tray"""
        self.showNormal()
        self.activateWindow()
        self.raise_()

    def toggle_auto_control_from_tray(self, checked):
        """Toggle auto control from tray menu"""
        if checked:
            self.radio_auto_control.setChecked(True)
        else:
            self.radio_manual_control.setChecked(True)

    def quit_application(self):
        """Quit the application"""
        QApplication.quit()

    def closeEvent(self, event):
        """Override close event to minimize to tray instead of closing"""
        if self.tray_icon.isVisible():
            self.hide()
            event.ignore()
        else:
            event.accept()

    def init_ui(self):
        # Set window properties
        self.setWindowTitle("Ryzen Master Commander")
        self.resize(900, 700)
        
        # Create central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Main layout
        main_layout = QVBoxLayout(central_widget)
        
        # Create splitter for graphs and controls
        splitter = QSplitter(Qt.Orientation.Vertical)
        main_layout.addWidget(splitter, 1)
        
        # Create graph widget
        self.graph_widget = QWidget()
        graph_layout = QVBoxLayout(self.graph_widget)
        
        # Add combined graph
        graph_group = QGroupBox("System Monitoring")
        graph_inner_layout = QVBoxLayout(graph_group)
        self.combined_graph = CombinedGraph(self)
        graph_inner_layout.addWidget(self.combined_graph)
        graph_layout.addWidget(graph_group)
        
        splitter.addWidget(self.graph_widget)
        
        # Controls container
        controls_container = QWidget()
        controls_layout = QHBoxLayout(controls_container)
        splitter.addWidget(controls_container)
        
        # Set initial sizes for splitter
        splitter.setSizes([380, 320])
        
        # Create TDP Controls group box
        tdp_group = QGroupBox("TDP Controls")
        tdp_layout = QVBoxLayout(tdp_group)
        self.profile_manager.create_widgets(tdp_group)
        controls_layout.addWidget(tdp_group)
        
        # Create Fan Controls group box
        fan_group = QGroupBox("Fan Controls")
        fan_layout = QVBoxLayout(fan_group)
        
        # Fan profile editor button
        fan_profile_editor_btn = QPushButton("Fan Profile Editor")
        fan_profile_editor_btn.clicked.connect(self.open_fan_profile_editor)
        fan_layout.addWidget(fan_profile_editor_btn)
        
        # Refresh interval slider
        refresh_label = QLabel("Refresh Interval (seconds):")
        fan_layout.addWidget(refresh_label)
        
        self.refresh_slider = QSlider(Qt.Orientation.Horizontal)
        self.refresh_slider.setRange(1, 30)
        self.refresh_slider.setValue(5)
        self.refresh_slider.setTickPosition(QSlider.TickPosition.TicksBelow)
        self.refresh_slider.setTickInterval(5)
        self.refresh_slider.valueChanged.connect(self.update_refresh_interval)
        fan_layout.addWidget(self.refresh_slider)
        
        refresh_value_layout = QHBoxLayout()
        refresh_value_layout.addWidget(QLabel("1"))
        refresh_value_layout.addStretch()
        refresh_value_layout.addWidget(QLabel("30"))
        fan_layout.addLayout(refresh_value_layout)
        
        # Fan control mode
        control_mode_group = QGroupBox("Fan Control Mode")
        control_mode_layout = QHBoxLayout(control_mode_group)
        
        self.radio_auto_control = QRadioButton("Auto Control")
        self.radio_auto_control.toggled.connect(self.set_auto_control)
        control_mode_layout.addWidget(self.radio_auto_control)
        
        self.radio_manual_control = QRadioButton("Manual Control")
        self.radio_manual_control.toggled.connect(self.set_manual_control)
        control_mode_layout.addWidget(self.radio_manual_control)
        
        fan_layout.addWidget(control_mode_group)
        
        # Manual fan speed slider
        manual_control_label = QLabel("Manual Fan Speed (%):")
        fan_layout.addWidget(manual_control_label)
        
        self.fan_speed_control_slider = QSlider(Qt.Orientation.Horizontal)
        self.fan_speed_control_slider.setRange(0, 100)
        self.fan_speed_control_slider.setValue(50)
        self.fan_speed_control_slider.setTickPosition(QSlider.TickPosition.TicksBelow)
        self.fan_speed_control_slider.setTickInterval(10)
        self.fan_speed_control_slider.valueChanged.connect(self.delayed_fan_setting)
        self.fan_speed_control_slider.setEnabled(False)  # Disabled by default (auto mode)
        fan_layout.addWidget(self.fan_speed_control_slider)
        
        fan_speed_value_layout = QHBoxLayout()
        fan_speed_value_layout.addWidget(QLabel("0%"))
        fan_speed_value_layout.addStretch()
        self.manual_control_value_label = QLabel("50%")
        fan_speed_value_layout.addWidget(self.manual_control_value_label)
        fan_speed_value_layout.addStretch()
        fan_speed_value_layout.addWidget(QLabel("100%"))
        fan_layout.addLayout(fan_speed_value_layout)
        
        # Toggle graph button
        toggle_graph_btn = QPushButton("Hide Graphs")
        toggle_graph_btn.clicked.connect(self.toggle_graph)
        self.toggle_graph_btn = toggle_graph_btn
        fan_layout.addWidget(toggle_graph_btn)
        
        fan_layout.addStretch()
        controls_layout.addWidget(fan_group)
        
        # Create status bar
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        
        # Status bar widgets
        self.temp_label = QLabel("Temperature: --°C")
        self.fan_speed_label = QLabel("Fan Speed: --%")
        self.current_profile_label = QLabel("Current Profile: --")
        
        # Add separators between status items
        self.status_bar.addPermanentWidget(self.temp_label)
        self.status_bar.addPermanentWidget(QFrame(frameShape=QFrame.Shape.VLine))
        self.status_bar.addPermanentWidget(self.fan_speed_label)
        self.status_bar.addPermanentWidget(QFrame(frameShape=QFrame.Shape.VLine))
        self.status_bar.addPermanentWidget(self.current_profile_label)
    
    def update_readings(self):
        temperature, fan_speed, current_profile = get_system_readings()
        
        # Update status bar labels
        self.temp_label.setText(f"Temperature: {temperature}°C")
        self.fan_speed_label.setText(f"Fan Speed: {fan_speed}%")
        self.current_profile_label.setText(f"Current Profile: {current_profile}")
        
        # Update combined graph
        self.combined_graph.update_data(temperature, fan_speed)
        
        # Update tray tooltip
        self.update_tray_tooltip()
        
        # Update tray menu auto control checkbox state
        if hasattr(self, 'toggle_auto_action'):
            self.toggle_auto_action.setChecked(self.radio_auto_control.isChecked())

    
    def update_refresh_interval(self):
        refresh_seconds = self.refresh_slider.value() * 1000  # Convert to milliseconds
        self.refresh_timer.setInterval(refresh_seconds)
    
    def delayed_fan_setting(self):
        # Cancel previous timer if it exists
        if hasattr(self, 'delay_timer') and self.delay_timer.isActive():
            self.delay_timer.stop()
        
        # Create a new timer to apply the setting after a delay
        self.delay_timer = QTimer(self)
        self.delay_timer.timeout.connect(self.apply_fan_speed)
        self.delay_timer.setSingleShot(True)
        self.delay_timer.start(1000)  # 1 second delay
        
        # Update the displayed value immediately
        slider_value = self.fan_speed_control_slider.value()
        self.manual_control_value_label.setText(f"{slider_value}%")
    
    def apply_fan_speed(self):
        slider_value = self.fan_speed_control_slider.value()
        try:
            subprocess.run(['pkexec', 'nbfc', 'set', '-s', str(slider_value)])
        except subprocess.CalledProcessError as e:
            print(f"Error setting fan speed: {e}")
    
    def set_auto_control(self):
        if self.radio_auto_control.isChecked():
            try:
                subprocess.run(['pkexec', 'nbfc', 'set', '-a'])
            except subprocess.CalledProcessError as e:
                print(f"Error setting automatic fan control: {e}")
            self.fan_speed_control_slider.setEnabled(False)
    
    def set_manual_control(self):
        if self.radio_manual_control.isChecked():
            self.fan_speed_control_slider.setEnabled(True)
    
    def toggle_graph(self):
        if self.graph_visible:
            self.graph_widget.hide()
            self.toggle_graph_btn.setText("Show Graphs")
        else:
            self.graph_widget.show()
            self.toggle_graph_btn.setText("Hide Graphs")
        
        self.graph_visible = not self.graph_visible
    
    def open_fan_profile_editor(self):
        active_nbfc_profile = None
        current_profile_text = self.current_profile_label.text() # e.g. "Current Profile: SomeProfileName"
        
        prefix = "Current Profile: "
        if current_profile_text.startswith(prefix):
            profile_name_part = current_profile_text[len(prefix):].strip()
            if profile_name_part and profile_name_part != "--" and profile_name_part != "n/a":
                active_nbfc_profile = profile_name_part
                
        self.fan_editor = FanProfileEditor(current_nbfc_profile_name=active_nbfc_profile)
        self.fan_editor.show()
```
---
## File: ryzen_master_commander/app/nbfc_manager.py

```py
import os
import subprocess
import json
from PyQt6.QtWidgets import QMessageBox, QDialog, QVBoxLayout, QListWidget, QPushButton, QLabel

class NBFCManager:
    """Class to manage NBFC (Notebook Fan Control) setup and configuration"""
    
    @staticmethod
    def is_nbfc_installed():
        """Check if NBFC is installed"""
        try:
            subprocess.run(['nbfc', '--version'], 
                          capture_output=True, 
                          text=True)
            return True
        except FileNotFoundError:
            return False
    
    @staticmethod
    def is_nbfc_running():
        """Check if NBFC service is running"""
        try:
            result = subprocess.run(['nbfc', 'status'], 
                                   capture_output=True, 
                                   text=True)
            return "ERROR: connect()" not in result.stderr
        except Exception:
            return False
    
    @staticmethod
    def is_nbfc_configured():
        """Check if NBFC is configured by looking for config file"""
        try:
            # First check if the service can start
            result = subprocess.run(['sudo', 'nbfc', 'start'], 
                                   capture_output=True, 
                                   text=True)
            # If there's an error about missing config file, it's not configured
            return "ERROR: /etc/nbfc/nbfc.json: No such file or directory" not in result.stderr
        except Exception:
            # If we can't run the command, assume it's not configured
            return False
    
    @staticmethod
    def update_nbfc_configs(parent=None):
        """Download available NBFC configs silently"""
        try:
            subprocess.run(['pkexec', 'nbfc', 'update'], 
                          capture_output=True, 
                          text=True)
            return True
        except Exception:
            return False
    
    @staticmethod
    def get_recommended_config():
        """Get the recommended config for this system"""
        try:
            result = subprocess.run(['pkexec', 'nbfc', 'config', '-r'], 
                                capture_output=True, 
                                text=True)
            
            stdout = result.stdout.strip()
            # print("NBFC config -r output with pkexec:")
            # print(repr(stdout))
            
            lines = stdout.split('\n')
            for line in lines:
                # Skip lines that are likely part of the header/info text
                if (line and 
                    "error" not in line.lower() and 
                    "found" not in line.lower() and
                    "config" not in line.lower() and
                    "recommend" not in line.lower() and
                    not line.startswith('-') and
                    not line.startswith('[')):
                    
                    config_name = line.strip()
                    if config_name:
                        print(f"Found possible config name: {config_name}")
                        return config_name
            
            print("No recommended nbfc config found.")
            return None
        except Exception as e:
            print(f"Error while getting recommended config: {str(e)}")
            return None
    
    @staticmethod
    def get_available_configs():
        """Get list of all available NBFC configs"""
        configs = []
        config_dirs = ['/usr/share/nbfc/configs', '/etc/nbfc/configs']
        
        for directory in config_dirs:
            if os.path.exists(directory):
                for file in os.listdir(directory):
                    if file.endswith('.json'):
                        configs.append(file[:-5])  # Remove .json extension
        
        return sorted(configs)
    
    @staticmethod
    def set_nbfc_config(config_name, parent=None):
        """Set NBFC to use the specified config"""
        try:
            result = subprocess.run(['pkexec', 'nbfc', 'config', '-s', config_name], 
                                   capture_output=True, 
                                   text=True)
            if "ERROR" in result.stderr:
                return False
            return True
        except Exception:
            return False
    
    @staticmethod
    def start_nbfc_service(parent=None):
        """Start the NBFC service"""
        try:
            subprocess.run(['pkexec', 'nbfc', 'start'], 
                          capture_output=True, 
                          text=True)
            return NBFCManager.is_nbfc_running()
        except Exception:
            return False

    @staticmethod
    def setup_nbfc(parent=None):
        """Complete NBFC setup process with minimal user interaction"""
        if not NBFCManager.is_nbfc_installed():
            QMessageBox.critical(parent, "NBFC Not Installed", 
                               "Notebook Fan Control (NBFC) is not installed on this system.\n"
                               "Please install it using your package manager.")
            return False
        
        # If NBFC is already running, we're good
        if NBFCManager.is_nbfc_running():
            return True
        print("NBFC is not running, attempting to start it...")

        # Try to start the service first
        if NBFCManager.start_nbfc_service(parent):
            return True
        
        print("NBFC service failed to start, checking configuration...")
        # If still not running, update configs silently
        NBFCManager.update_nbfc_configs()
        
        # Try to get and apply recommended config automatically
        recommended = NBFCManager.get_recommended_config()
        
        if recommended:
            # Apply recommended config silently
            if NBFCManager.set_nbfc_config(recommended):
                print(f"Applied recommended config: {recommended}")
                return NBFCManager.start_nbfc_service()
        
        # Only show dialog if we couldn't find or apply a recommended config
        print("No recommended config found or failed to apply, showing selection dialog...")
        config_dialog = ConfigSelectionDialog(parent)
        if config_dialog.exec_() == QDialog.Accepted and config_dialog.selected_config:
            if NBFCManager.set_nbfc_config(config_dialog.selected_config):
                return NBFCManager.start_nbfc_service()
        
        return False


class ConfigSelectionDialog(QDialog):
    """Dialog for selecting an NBFC configuration"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Select NBFC Configuration")
        self.setMinimumWidth(500)
        self.setMinimumHeight(400)
        
        self.selected_config = None
        
        layout = QVBoxLayout(self)
        
        # Instructions with more detailed guidance
        instructions = QLabel(
            "Select your model or the nearest match you can find.\n\n"
            "If your model is not supported, check the nbfc-linux project at\n"
            "https://github.com/nbfc-linux/ for assistance."
        )
        instructions.setWordWrap(True)
        layout.addWidget(instructions)
        
        # Config list
        self.config_list = QListWidget()
        layout.addWidget(self.config_list)
        
        # Populate list
        configs = NBFCManager.get_available_configs()
        for config in configs:
            self.config_list.addItem(config)
        
        # Buttons
        button_layout = QVBoxLayout()
        select_button = QPushButton("Select")
        select_button.clicked.connect(self.accept_selection)
        cancel_button = QPushButton("Cancel")
        cancel_button.clicked.connect(self.reject)
        
        button_layout.addWidget(select_button)
        button_layout.addWidget(cancel_button)
        layout.addLayout(button_layout)
    
    def accept_selection(self):
        """Accept the selected configuration"""
        current_item = self.config_list.currentItem()
        if current_item:
            self.selected_config = current_item.text()
            self.accept()
        else:
            QMessageBox.warning(self, "Selection Required", 
                              "Please select a configuration from the list.")
```
---
## File: ryzen_master_commander/app/profile_manager.py

```py
import json
import os
from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QGroupBox, QLabel, 
                           QComboBox, QLineEdit, QCheckBox, QPushButton, QInputDialog)
from PyQt6.QtCore import pyqtSlot, Qt

from ryzen_master_commander.app.system_utils import apply_tdp_settings

class ProfileManager:
    def __init__(self):
        # Check multiple potential profile directories
        potential_dirs = [
            "./tdp_profiles",  # Development location
            "/usr/share/ryzen-master-commander/tdp_profiles",  # System-wide installation
            os.path.expanduser("~/.local/share/ryzen-master-commander/tdp_profiles")  # User installation
        ]
        
        # Use the first directory that exists
        self.profiles_directory = next((d for d in potential_dirs if os.path.exists(d)), "./tdp_profiles")
        print(f"Using profiles from: {self.profiles_directory}")
        
        self.current_profile = None
        self.cached_profiles = self.load_profiles()
        
    def create_widgets(self, parent):
        self.parent = parent
        layout = parent.layout()
        
        # Profile selection
        profile_layout = QHBoxLayout()
        profile_layout.addWidget(QLabel("Performance Profile:"))
        
        self.profile_dropdown = QComboBox()
        # Explicitly connect with the correct type
        self.profile_dropdown.currentIndexChanged.connect(self.on_profile_select)
        profile_layout.addWidget(self.profile_dropdown)
        layout.addLayout(profile_layout)
        
        # TDP settings
        # Fast limit
        fast_limit_layout = QHBoxLayout()
        fast_limit_layout.addWidget(QLabel("Fast Limit (W):"))
        self.fast_limit_entry = QLineEdit()
        fast_limit_layout.addWidget(self.fast_limit_entry)
        layout.addLayout(fast_limit_layout)
        
        # Slow limit
        slow_limit_layout = QHBoxLayout()
        slow_limit_layout.addWidget(QLabel("Slow Limit (W):"))
        self.slow_limit_entry = QLineEdit()
        slow_limit_layout.addWidget(self.slow_limit_entry)
        layout.addLayout(slow_limit_layout)
        
        # Slow time
        slow_time_layout = QHBoxLayout()
        slow_time_layout.addWidget(QLabel("Slow Time (s):"))
        self.slow_time_entry = QLineEdit()
        slow_time_layout.addWidget(self.slow_time_entry)
        layout.addLayout(slow_time_layout)
        
        # Tctl temp
        tctl_temp_layout = QHBoxLayout()
        tctl_temp_layout.addWidget(QLabel("Tctl Temp (°C):"))
        self.tctl_temp_entry = QLineEdit()
        tctl_temp_layout.addWidget(self.tctl_temp_entry)
        layout.addLayout(tctl_temp_layout)
        
        # APU skin temp
        apu_skin_temp_layout = QHBoxLayout()
        apu_skin_temp_layout.addWidget(QLabel("APU Skin Temp (°C):"))
        self.apu_skin_temp_entry = QLineEdit()
        apu_skin_temp_layout.addWidget(self.apu_skin_temp_entry)
        layout.addLayout(apu_skin_temp_layout)
        
        # Performance options
        performance_group = QGroupBox("Performance Mode")
        performance_layout = QHBoxLayout(performance_group)
        
        self.max_performance_var = QCheckBox("Max Performance")
        self.max_performance_var.stateChanged.connect(
            lambda: self.power_saving_var.setChecked(False) if self.max_performance_var.isChecked() else None
        )
        performance_layout.addWidget(self.max_performance_var)
        
        self.power_saving_var = QCheckBox("Power Saving")
        self.power_saving_var.stateChanged.connect(
            lambda: self.max_performance_var.setChecked(False) if self.power_saving_var.isChecked() else None
        )
        performance_layout.addWidget(self.power_saving_var)
        
        layout.addWidget(performance_group)
        
        # Buttons
        button_layout = QHBoxLayout()
        
        apply_tdp_button = QPushButton("Apply TDP Settings")
        apply_tdp_button.clicked.connect(lambda: apply_tdp_settings(self.current_profile))
        button_layout.addWidget(apply_tdp_button)
        
        save_profile_button = QPushButton("Save Profile")
        save_profile_button.clicked.connect(self.save_profile)
        button_layout.addWidget(save_profile_button)
        
        layout.addLayout(button_layout)
        layout.addStretch()
        
        # Populate profile dropdown
        self.update_profile_dropdown()
        
    def load_profiles(self):
        profiles = []
        if not os.path.exists(self.profiles_directory):
            os.makedirs(self.profiles_directory)
            print(f"Created profiles directory: {self.profiles_directory}")
        
        # Debug: list all files in the directory
        files = os.listdir(self.profiles_directory)
        print(f"Found {len(files)} files in profiles directory: {files}")
        
        for file in files:
            if file.endswith(".json"):
                file_path = os.path.join(self.profiles_directory, file)
                try:
                    with open(file_path, "r") as f:
                        file_content = f.read()
                        profile = json.loads(file_content)
                        
                        # Validate profile has required fields
                        if "name" not in profile:
                            print(f"Warning: Profile '{file}' missing required 'name' field")
                            profile["name"] = os.path.splitext(file)[0]  # Use filename as name
                        
                        profiles.append(profile)
                        print(f"Successfully loaded profile: {profile['name']}")
                except json.JSONDecodeError as e:
                    print(f"Error loading profile '{file}': {e}")
                    print(f"Content causing error: {file_content[:100]}...")
                except Exception as e:
                    print(f"Unexpected error loading profile '{file}': {e}")
        
        print(f"Loaded {len(profiles)} profiles total")
        return profiles  # Return the loaded profiles

    def update_profile_dropdown(self):
        if self.cached_profiles:
            self.profile_dropdown.clear()
            for profile in self.cached_profiles:
                self.profile_dropdown.addItem(profile["name"])
            
            # Select first profile by default if none is selected
            if self.profile_dropdown.currentIndex() == -1 and self.profile_dropdown.count() > 0:
                self.profile_dropdown.setCurrentIndex(0)

    # Fixed method to properly handle the signal
    def on_profile_select(self, index):
        """Handle profile selection from dropdown"""
        if index < 0 or not self.cached_profiles or index >= len(self.cached_profiles):
            return
            
        selected_profile = self.cached_profiles[index]
        self.current_profile = selected_profile
        
        # Update the entries with profile values
        self.fast_limit_entry.setText(str(self.current_profile["fast-limit"]))
        self.slow_limit_entry.setText(str(self.current_profile["slow-limit"]))
        self.slow_time_entry.setText(str(self.current_profile["slow-time"]))
        self.tctl_temp_entry.setText(str(self.current_profile["tctl-temp"]))
        self.apu_skin_temp_entry.setText(str(self.current_profile["apu-skin-temp"]))
        self.max_performance_var.setChecked(self.current_profile["max-performance"])
        self.power_saving_var.setChecked(self.current_profile["power-saving"])
        
        # Apply the profile
        apply_tdp_settings(self.current_profile)

    def save_profile(self):
        profile_name, ok = QInputDialog.getText(
            self.parent, "Save Profile", "Enter profile name:"
        )
        
        if ok and profile_name:
            profile = {
                "name": profile_name,
                "fast-limit": int(self.fast_limit_entry.text()),
                "slow-limit": int(self.slow_limit_entry.text()),
                "slow-time": int(self.slow_time_entry.text()),
                "tctl-temp": int(self.tctl_temp_entry.text()),
                "apu-skin-temp": int(self.apu_skin_temp_entry.text()),
                "max-performance": self.max_performance_var.isChecked(),
                "power-saving": self.power_saving_var.isChecked()
            }
            
            # Save profile to file
            with open(os.path.join(self.profiles_directory, f"{profile_name}.json"), "w") as f:
                json.dump(profile, f, indent=2)
            
            # Update cached profiles
            self.cached_profiles = self.load_profiles()
            
            # Update dropdown with new profile
            self.update_profile_dropdown()
            
            # Select the new profile
            index = self.profile_dropdown.findText(profile_name)
            if index >= 0:
                self.profile_dropdown.setCurrentIndex(index)
```
---
## File: ryzen_master_commander/app/system_utils.py

```py
import subprocess
import re
import os

def get_system_readings():
    try:
        output = subprocess.check_output(['nbfc', 'status', '-a'], text=True)
    except subprocess.CalledProcessError as e:
        print(f"Failed to execute 'nbfc status -a': {e}")
        return "n/a", "n/a", "n/a"
    except FileNotFoundError:
        print("nbfc command not found. Make sure NoteBook FanControl is installed.")
        return "n/a", "n/a", "n/a"

    temperature_match = re.search(r'Temperature\s+:\s+(\d+\.?\d*)', output)
    fan_speed_match = re.search(r'Current Fan Speed\s+:\s+(\d+\.?\d*)', output)
    current_profile_match = re.search(r'Selected Config Name\s+:\s+(.*?)$', output, re.MULTILINE)

    temperature = temperature_match.group(1) if temperature_match else "n/a"
    fan_speed = fan_speed_match.group(1) if fan_speed_match else "n/a"
    current_profile = current_profile_match.group(1) if current_profile_match else "n/a"
    return temperature, fan_speed, current_profile

def apply_tdp_settings(current_profile):
    if current_profile:
        command = ['pkexec', 'ryzenadj']
        for key, value in current_profile.items():
            if key in ["fast-limit", "slow-limit"]:
                command.extend([f'--{key}={value * 1000}'])
            elif key == "slow-time":
                command.extend([f'--{key}={value * 1000}'])
            elif key not in ["name", "max-performance", "power-saving"]:
                command.extend([f'--{key}={value}'])
        if current_profile.get("power-saving"):
            command.append("--power-saving")
        elif current_profile.get("max-performance"):
            command.append("--max-performance")
        try:
            subprocess.run(command)
            print(f"Applied TDP settings with command: {' '.join(command)}")
            return True, "TDP settings applied successfully"
        except subprocess.CalledProcessError as e:
            error_msg = f"Error applying TDP settings: {e}"
            print(error_msg)
            return False, error_msg
    return False, "No profile selected"

def apply_fan_profile(profile_name):
    """Apply a fan profile by name with nbfc command"""
    try:
        # Use the profile name (without extension) with nbfc config command
        profile_name = os.path.splitext(os.path.basename(profile_name))[0]
        subprocess.run(['pkexec', 'nbfc', 'config', '-a', profile_name], check=True)
        return True, f"Fan profile '{profile_name}' applied successfully"
    except Exception as e:
        return False, f"Error applying fan profile: {str(e)}"
```
---
## File: ryzen_master_commander/main.py

```py
import sys
import os
from PyQt6.QtWidgets import QApplication
from PyQt6.QtGui import QIcon
from ryzen_master_commander.app.main_window import MainWindow

def main():
    # Create Qt application
    # For Wayland/X11 icon and .desktop file association:
    # Set the desktop file name (without .desktop extension)
    QApplication.setDesktopFileName("ryzen-master-commander")
    app = QApplication(sys.argv)
    app.setApplicationName("ryzen-master-commander") # Match StartupWMClass and Icon name
    
    # Set application icon
    icon_paths = [
        "/usr/share/icons/hicolor/128x128/apps/ryzen-master-commander.png",
        "./share/icons/hicolor/128x128/apps/ryzen-master-commander.png",
        "./img/icon.png"
    ]
    
    for path in icon_paths:
        if os.path.exists(path):
            app.setWindowIcon(QIcon(path))
            break
    
    app.setQuitOnLastWindowClosed(False)

    # Configure PyQtGraph for dark/light mode
    try:
        import pyqtgraph as pg
        import subprocess # Added for KDE theme detection
        # Check for KDE dark mode
        is_dark_mode = False
        
        if os.environ.get('XDG_CURRENT_DESKTOP') == 'KDE':
            try:
                result = subprocess.run(
                    ["kreadconfig5", "--group", "General", "--key", "ColorScheme"],
                    capture_output=True, text=True
                )
                is_dark_mode = "dark" in result.stdout.strip().lower()
            except Exception as e:
                print(f"Error detecting KDE theme: {e}")
        
        # Another approach for dark mode detection
        if not is_dark_mode:
            try:
                from PyQt5.QtGui import QPalette
                app_palette = app.palette()
                # If text is lighter than background, we're likely in dark mode
                bg_color = app_palette.color(QPalette.Window).lightness()
                text_color = app_palette.color(QPalette.WindowText).lightness()
                is_dark_mode = text_color > bg_color
            except Exception as e:
                print(f"Error using palette for theme detection: {e}")
        
        print(f"Dark mode detected: {is_dark_mode}")
        
        # Set PyQtGraph theme
        if is_dark_mode:
            pg.setConfigOption('background', 'k')
            pg.setConfigOption('foreground', 'w')
        else:
            pg.setConfigOption('background', 'w')
            pg.setConfigOption('foreground', 'k')
    except ImportError:
        print("PyQtGraph not available")
    
    # Create and show the main window
    main_window = MainWindow()
    main_window.show()
    
    # Start the application
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
```
---
## File: setup.py

```py
from setuptools import setup, find_packages
import os

# All paths for data_files must be relative to this setup.py file.

fan_profiles_source_dir = 'share/ryzen-master-commander/fan_profiles'
tdp_profiles_source_dir = 'share/ryzen-master-commander/tdp_profiles'

data_files = [
    # Target installation directory, [list of source files relative to setup.py]
    ('share/applications', ['share/applications/ryzen-master-commander.desktop']),
    (fan_profiles_source_dir, # Target dir is same as source for these
     [os.path.join(fan_profiles_source_dir, f) for f in os.listdir(fan_profiles_source_dir) if os.path.isfile(os.path.join(fan_profiles_source_dir, f))]),
    (tdp_profiles_source_dir, # Target dir is same as source for these
     [os.path.join(tdp_profiles_source_dir, f) for f in os.listdir(tdp_profiles_source_dir) if os.path.isfile(os.path.join(tdp_profiles_source_dir, f))]),
    # REMOVED 'bin/ryzen-master-commander' from here.
    # Keep ryzen-master-commander-helper if it's a separate script not managed by entry_points
    ('bin', ['bin/ryzen-master-commander-helper']), # Assuming helper is still needed as a separate file
    ('share/polkit-1/actions', ['polkit/com.merrythieves.ryzenadj.policy']),
]

# Add icon files using relative paths
for size in ['16x16', '32x32', '64x64', '128x128']:
    icon_source_file_rel = os.path.join('share/icons/hicolor', size, 'apps', 'ryzen-master-commander.png')
    icon_target_dir = os.path.join('share/icons/hicolor', size, 'apps')
    if os.path.isfile(icon_source_file_rel):
        data_files.append((icon_target_dir, [icon_source_file_rel]))

setup(
    #get version from ./ver.txt
    version = open('version.txt').read().strip(),
    name="ryzen-master-commander",
    author="sam1am",
    author_email="noreply@merrythieves.com",
    description="TDP and fan control for AMD Ryzen processors",
    url="https://github.com/sam1am/Ryzen-Master-Commander",
    packages=['ryzen_master_commander', 'ryzen_master_commander.app'],
    include_package_data=True,
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: POSIX :: Linux",
    ],
    license_files=('LICENSE',),
    install_requires=[
        "PyQt6",
        "pyqtgraph",
        "numpy",
        "Pillow",
        "pystray",
    ],
    python_requires=">=3.8",
    data_files=data_files,
    entry_points={
        'console_scripts': [
            'ryzen-master-commander=ryzen_master_commander.main:main', # This will create /usr/bin/ryzen-master-commander
        ],
    },
)
```
---
