./build_arch.sh
./build_deb.sh
./build_rpm.sh